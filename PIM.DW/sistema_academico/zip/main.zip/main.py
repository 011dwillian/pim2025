# main.py
import tkinter as tk
from tkinter import messagebox
from database import inicializar_banco, conectar
from aluno.aluno import tela_aluno
from professor.professor import tela_professor
import re

# Inicializa o banco (cria se não existir)
inicializar_banco()

# Validações
def validar_ra(ra):
    return bool(re.match(r"^[A-Za-z0-9]{7}$", ra))

def validar_senha(senha):
    return len(senha) == 5 and senha.isdigit()

def validar_email_unip(email):
    return isinstance(email, str) and email.endswith("@unip.edu.br")

# Autenticação (aluno por RA, professor por e-mail)
def autenticar(tipo, identificador, senha):
    conn = conectar()
    c = conn.cursor()
    if tipo == "aluno":
        c.execute("SELECT * FROM alunos WHERE ra=? AND senha=?", (identificador, senha))
    else:
        c.execute("SELECT * FROM professores WHERE email=? AND senha=?", (identificador, senha))
    dados = c.fetchone()
    conn.close()
    return dados

# Janelas de cadastro
def tela_cadastro(tipo):
    cad = tk.Toplevel()
    cad.title(f"Cadastro - {tipo.capitalize()}")
    cad.geometry("420x420")

    tk.Label(cad, text=f"Cadastro de {tipo.capitalize()}", font=("Arial", 12, "bold")).pack(pady=8)

    entries = {}

    def add_field(label_text, key, show=None):
        tk.Label(cad, text=label_text).pack()
        e = tk.Entry(cad, show=show)
        e.pack(pady=4)
        entries[key] = e

    add_field("Nome completo:", "nome")
    if tipo == "aluno":
        add_field("Data de nascimento (AAAA-MM-DD):", "nasc")
        add_field("RA (7 dígitos):", "ra")
        add_field("E-mail institucional (@unip.edu.br):", "email")
        add_field("Senha (5 dígitos):", "senha", show="*")
    else:
        add_field("E-mail institucional (@unip.edu.br):", "email")
        add_field("Disciplina:", "disciplina")
        add_field("Senha (5 dígitos):", "senha", show="*")

    def salvar():
        vals = {k: e.get().strip() for k, e in entries.items()}
        if any(v == "" for v in vals.values()):
            messagebox.showerror("Erro", "Preencha todos os campos.")
            return

        if tipo == "aluno":
            if not validar_ra(vals["ra"]):
                messagebox.showerror("Erro", "RA inválido. Deve ter 7 caracteres alfanuméricos.")
                return
            if not validar_email_unip(vals["email"]):
                messagebox.showerror("Erro", "E-mail deve ser institucional (@unip.edu.br).")
                return
            if not validar_senha(vals["senha"]):
                messagebox.showerror("Erro", "Senha inválida (5 dígitos).")
                return
            # Inserir
            conn = conectar()
            c = conn.cursor()
            try:
                c.execute("INSERT INTO alunos (nome, data_nascimento, ra, senha, email) VALUES (?, ?, ?, ?, ?)",
                          (vals["nome"], vals["nasc"], vals["ra"], vals["senha"], vals["email"]))
                conn.commit()
                messagebox.showinfo("Sucesso", "Cadastro de aluno realizado!")
                cad.destroy()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao cadastrar: {e}")
            finally:
                conn.close()
        else:
            if not validar_email_unip(vals["email"]):
                messagebox.showerror("Erro", "E-mail deve ser institucional (@unip.edu.br).")
                return
            if not validar_senha(vals["senha"]):
                messagebox.showerror("Erro", "Senha inválida (5 dígitos).")
                return
            conn = conectar()
            c = conn.cursor()
            try:
                c.execute("INSERT INTO professores (nome, email, senha, disciplina) VALUES (?, ?, ?, ?)",
                          (vals["nome"], vals["email"], vals["senha"], vals["disciplina"]))
                conn.commit()
                messagebox.showinfo("Sucesso", "Cadastro de professor realizado!")
                cad.destroy()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao cadastrar: {e}")
            finally:
                conn.close()

    tk.Button(cad, text="Salvar Cadastro", bg="#4CAF50", fg="white", command=salvar).pack(pady=12)

# Tela de login
def tela_login(tipo):
    win = tk.Toplevel()
    win.title(f"Login - {tipo.capitalize()}")
    win.geometry("360x240")
    tk.Label(win, text=f"Login de {tipo.capitalize()}", font=("Arial", 12, "bold")).pack(pady=8)

    if tipo == "aluno":
        tk.Label(win, text="RA:").pack()
        entry_id = tk.Entry(win)
        entry_id.pack(pady=4)
    else:
        tk.Label(win, text="E-mail institucional:").pack()
        entry_id = tk.Entry(win)
        entry_id.pack(pady=4)

    tk.Label(win, text="Senha:").pack()
    entry_senha = tk.Entry(win, show="*")
    entry_senha.pack(pady=4)

    def entrar():
        identificador = entry_id.get().strip()
        senha = entry_senha.get().strip()
        if identificador == "" or senha == "":
            messagebox.showerror("Erro", "Preencha todos os campos.")
            return
        dados = autenticar(tipo, identificador, senha)
        if dados:
            messagebox.showinfo("Sucesso", f"Bem-vindo(a), {dados[1]}!")
            win.destroy()
            if tipo == "aluno":
                tela_aluno(dados)   # passa tupla do aluno
            else:
                tela_professor(dados)
        else:
            messagebox.showerror("Erro", "Credenciais incorretas.")

    tk.Button(win, text="Entrar", bg="#4CAF50", fg="white", command=entrar).pack(pady=10)
    tk.Button(win, text="Não tem cadastro? Clique aqui", command=lambda: tela_cadastro(tipo)).pack(pady=4)

# Janela inicial
def main():
    root = tk.Tk()
    root.title("Sistema Acadêmico com Apoio de IA")
    root.geometry("420x300")

    tk.Label(root, text="Sistema Acadêmico Colaborativo", font=("Arial", 14, "bold")).pack(pady=12)
    tk.Label(root, text="Escolha seu perfil:", font=("Arial", 11)).pack(pady=6)

    tk.Button(root, text="Sou Aluno", width=20, bg="#2196F3", fg="white", command=lambda: tela_login("aluno")).pack(pady=8)
    tk.Button(root, text="Sou Professor", width=20, bg="#673AB7", fg="white", command=lambda: tela_login("professor")).pack(pady=8)

    tk.Label(root, text="Credenciais de exemplo: RA=A1B2C3D senha=12345 | prof: carlos@unip.edu.br senha=12345", font=("Arial", 8)).pack(side="bottom", pady=8)

    root.mainloop()

if __name__ == "__main__":
    main()
