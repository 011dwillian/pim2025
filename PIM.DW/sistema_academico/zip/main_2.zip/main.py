# main.py
"""
Sistema Acadêmico Colaborativo - UNIP
Curso: Análise e Desenvolvimento de Sistemas (Noturno)
Campus: Anchieta - 2º semestre

Este arquivo contém:
- Tela inicial (seleção de perfil)
- Fluxo de login de Aluno, Professor e Coordenador
- Telas de cadastro de Aluno/Professor
- Criação / complementação de tabelas do banco
- Popularização do banco com dados padrão (alunos, professores, matérias, conteúdos)
Obs.: as telas detalhadas de Aluno/Professor continuam nos módulos:
    - aluno.aluno.tela_aluno(dados_aluno)
    - professor.professor.tela_professor(dados_professor)
"""

import tkinter as tk
from tkinter import messagebox, ttk
import re
from database import inicializar_banco, conectar
from aluno.aluno import tela_aluno
from professor.professor import tela_professor

# ---------------------- CONSTANTES DE NEGÓCIO ---------------------- #

COR_AZUL_MARINHO = "#001f3f"
COR_AZUL_CLARO = "#e3f2fd"
COR_AMARELO_UNIP = "#ffd600"
COR_AMARELO_UNIP_ESCURO = "#ffb300"
COR_VERDE_NOTA = "#2e7d32"
COR_VERMELHO_NOTA = "#c62828"

COORDENADOR_EMAIL = "coordenadorads@unip.edu.br"
COORDENADOR_SENHA = "1234567"

MATERIAS_FIXAS = [
    "Engenharia de Software Ágil",
    "Algoritmo e Estrutura de Dados com Python",
    "Programação Estruturada em C",
    "Análise e Projeto de Sistemas",
]

PROFESSORES_PADRAO = [
    ("Airton",   "airton@unip.edu.br",   "12345", MATERIAS_FIXAS[0]),
    ("Ageu",     "ageu@unip.edu.br",     "12345", MATERIAS_FIXAS[1]),
    ("Ivan",     "ivan@unip.edu.br",     "12345", MATERIAS_FIXAS[2]),
    ("Glauco",   "glauco@unip.edu.br",   "12345", MATERIAS_FIXAS[3]),
]

ALUNOS_PADRAO = [
    ("David Willian",      "10/07/2000", "A123456", "12345", "david@unip.edu.br"),
    ("Guilherme Mendonça", "10/07/2000", "B123456", "12345", "guilherme@unip.edu.br"),
    ("Walisson Pereira",   "10/07/2000", "C123456", "12345", "walisson@unip.edu.br"),
    ("Thomas Lopes",       "10/07/2000", "D123456", "12345", "thomas@unip.edu.br"),
    ("Vinicius Hisashi",   "10/07/2000", "E123456", "12345", "vinicius@unip.edu.br"),
]

# ---------------------- FUNÇÕES AUXILIARES / DB ---------------------- #

def criar_tabelas_complementares():
    """Garante que as tabelas necessárias existam.
    Usa CREATE TABLE IF NOT EXISTS para não conflitar com inicializar_banco().
    """
    conn = conectar()
    c = conn.cursor()

    # Matérias
    c.execute("""
        CREATE TABLE IF NOT EXISTS materias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT UNIQUE NOT NULL
        )
    """)

    # Matriculas (Aluno x Matéria)
    c.execute("""
        CREATE TABLE IF NOT EXISTS matriculas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_ra TEXT NOT NULL,
            materia_id INTEGER NOT NULL,
            FOREIGN KEY (materia_id) REFERENCES materias(id)
        )
    """)

    # Notas
    c.execute("""
        CREATE TABLE IF NOT EXISTS notas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_ra TEXT NOT NULL,
            materia_id INTEGER NOT NULL,
            np1 REAL,
            np2 REAL,
            media REAL,
            FOREIGN KEY (materia_id) REFERENCES materias(id)
        )
    """)

    # Faltas
    c.execute("""
        CREATE TABLE IF NOT EXISTS faltas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_ra TEXT NOT NULL,
            materia_id INTEGER NOT NULL,
            total_faltas INTEGER DEFAULT 0,
            total_aulas INTEGER DEFAULT 0,
            FOREIGN KEY (materia_id) REFERENCES materias(id)
        )
    """)

    # Ocorrências
    c.execute("""
        CREATE TABLE IF NOT EXISTS ocorrencias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_ra TEXT NOT NULL,
            materia_id INTEGER,
            descricao TEXT,
            data_hora TEXT
        )
    """)

    # Conteúdos programáticos (cronograma)
    c.execute("""
        CREATE TABLE IF NOT EXISTS conteudos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            materia_id INTEGER NOT NULL,
            ordem INTEGER NOT NULL,
            titulo TEXT NOT NULL,
            dado INTEGER DEFAULT 0,
            data_hora_dado TEXT,
            FOREIGN KEY (materia_id) REFERENCES materias(id)
        )
    """)

    conn.commit()
    conn.close()


def popular_dados_iniciais():
    """Insere matérias, professores, alunos e conteúdos padrão, se ainda não existirem."""
    conn = conectar()
    c = conn.cursor()

    # Matérias
    for nome in MATERIAS_FIXAS:
        c.execute("INSERT OR IGNORE INTO materias (nome) VALUES (?)", (nome,))

    # Professores
    for nome, email, senha, disciplina in PROFESSORES_PADRAO:
        c.execute(
            "INSERT OR IGNORE INTO professores (nome, email, senha, disciplina) VALUES (?, ?, ?, ?)",
            (nome, email, senha, disciplina),
        )

    # Alunos
    for nome, nasc, ra, senha, email in ALUNOS_PADRAO:
        c.execute(
            "INSERT OR IGNORE INTO alunos (nome, data_nascimento, ra, senha, email) VALUES (?, ?, ?, ?, ?)",
            (nome, nasc, ra, senha, email),
        )

    # Matricular todos os alunos em todas as matérias + criar notas/faltas base
    c.execute("SELECT id FROM materias")
    materias = [row[0] for row in c.fetchall()]

    for _, _, ra, _, _ in ALUNOS_PADRAO:
        for materia_id in materias:
            # Matriculas
            c.execute(
                """
                INSERT OR IGNORE INTO matriculas (aluno_ra, materia_id)
                VALUES (?, ?)
                """,
                (ra, materia_id),
            )
            # Notas base
            c.execute(
                """
                INSERT OR IGNORE INTO notas (aluno_ra, materia_id, np1, np2, media)
                VALUES (?, ?, NULL, NULL, NULL)
                """,
                (ra, materia_id),
            )
            # Faltas base (20 aulas/mês * 6 meses = 120 aulas como base semestral)
            c.execute(
                """
                INSERT OR IGNORE INTO faltas (aluno_ra, materia_id, total_faltas, total_aulas)
                VALUES (?, ?, 0, 120)
                """,
                (ra, materia_id),
            )

    # Conteúdos padrão (5 por matéria)
    c.execute("SELECT id, nome FROM materias")
    materias_com_nomes = c.fetchall()
    for materia_id, nome in materias_com_nomes:
        # Verifica se já existem conteúdos
        c.execute("SELECT COUNT(*) FROM conteudos WHERE materia_id = ?", (materia_id,))
        qtd = c.fetchone()[0]
        if qtd == 0:
            for i in range(1, 6):
                titulo = f"Aula {i} - Conteúdo de {nome}"
                c.execute(
                    """
                    INSERT INTO conteudos (materia_id, ordem, titulo, dado)
                    VALUES (?, ?, ?, 0)
                    """,
                    (materia_id, i, titulo),
                )

    conn.commit()
    conn.close()


# ---------------------- VALIDAÇÕES ---------------------- #

def validar_ra(ra: str) -> bool:
    """RA: exatamente 7 caracteres alfanuméricos."""
    return bool(re.fullmatch(r"[A-Za-z0-9]{7}", ra))


def validar_senha(senha: str) -> bool:
    """Senha: exatamente 5 dígitos numéricos."""
    return bool(re.fullmatch(r"\d{5}", senha))


def validar_email_unip(email: str) -> bool:
    return email.endswith("@unip.edu.br") and "@" in email


def validar_data_br(data: str) -> bool:
    """Valida data no formato DD/MM/AAAA (simples)."""
    m = re.fullmatch(r"(\d{2})/(\d{2})/(\d{4})", data)
    if not m:
        return False
    dia, mes, ano = map(int, m.groups())
    if not (1 <= dia <= 31 and 1 <= mes <= 12 and 1900 <= ano <= 2100):
        return False
    return True


# ---------------------- AUTENTICAÇÃO ---------------------- #

def autenticar(tipo: str, identificador: str, senha: str):
    """Autentica aluno ou professor no banco."""
    conn = conectar()
    c = conn.cursor()
    if tipo == "aluno":
        c.execute(
            "SELECT * FROM alunos WHERE ra = ? AND senha = ?",
            (identificador, senha),
        )
    else:
        c.execute(
            "SELECT * FROM professores WHERE email = ? AND senha = ?",
            (identificador, senha),
        )
    dados = c.fetchone()
    conn.close()
    return dados


# ---------------------- CADASTRO ---------------------- #

def tela_cadastro(tipo: str):
    """Tela de cadastro reutilizável para Aluno ou Professor."""
    cad = tk.Toplevel()
    cad.title(f"Cadastro - {tipo.capitalize()}")
    cad.configure(bg=COR_AZUL_MARINHO)
    cad.geometry("420x480")

    tk.Label(
        cad,
        text=f"Cadastro de {tipo.capitalize()}",
        font=("Arial", 12, "bold"),
        bg=COR_AZUL_MARINHO,
        fg=COR_AMARELO_UNIP,
    ).pack(pady=8)

    frame = tk.Frame(cad, bg="white")
    frame.pack(padx=20, pady=10, fill="both", expand=True)

    entries = {}

    def add_field(label_text, key, show=None, vcmd=None):
        lbl = tk.Label(frame, text=label_text, bg="white")
        lbl.pack(pady=(8, 0))
        e = tk.Entry(frame, show=show, validate="key" if vcmd else "none",
                     validatecommand=vcmd)
        e.pack(pady=4, fill="x", padx=10)
        entries[key] = e

    if tipo == "aluno":
        add_field("Nome completo:", "nome")

        # Data no padrão brasileiro com máscara
        def on_validate_data(P):
            # permite apagar conteúdo
            if P == "":
                return True
            # mantemos só dígitos
            import re as _re
            texto_limpo = _re.sub(r"[^0-9]", "", P)[:8]
            novo = ""
            if len(texto_limpo) >= 2:
                novo += texto_limpo[:2]
            else:
                novo += texto_limpo
            if len(texto_limpo) >= 3:
                novo += "/" + texto_limpo[2:4]
            if len(texto_limpo) >= 5:
                novo += "/" + texto_limpo[4:]
            entries["nasc"].delete(0, tk.END)
            entries["nasc"].insert(0, novo)
            return False  # já atualizamos manualmente

        vcmd_data = (cad.register(on_validate_data), "%P")
        add_field("Data de nascimento (DD/MM/AAAA):", "nasc", vcmd=vcmd_data)
        add_field("RA (7 caracteres):", "ra")
        add_field("E-mail institucional (@unip.edu.br):", "email")
        add_field("Senha (5 dígitos):", "senha", show="*")
    else:
        add_field("Nome completo:", "nome")
        add_field("E-mail institucional (@unip.edu.br):", "email")
        # Combobox para escolher disciplina (uma única)
        lbl = tk.Label(frame, text="Disciplina:", bg="white")
        lbl.pack(pady=(8, 0))
        disciplina_var = tk.StringVar()
        combo = ttk.Combobox(
            frame,
            textvariable=disciplina_var,
            values=MATERIAS_FIXAS,
            state="readonly",
        )
        combo.pack(pady=4, fill="x", padx=10)
        entries["disciplina"] = combo
        add_field("Senha (5 dígitos):", "senha", show="*")

    def salvar():
        vals = {k: e.get().strip() for k, e in entries.items()}

        if tipo == "aluno":
            # validações
            if not vals.get("nome"):
                messagebox.showerror("Erro", "Informe o nome.")
                return
            if not validar_data_br(vals.get("nasc", "")):
                messagebox.showerror("Erro", "Data inválida. Use o formato DD/MM/AAAA.")
                return
            if not validar_ra(vals.get("ra", "")):
                messagebox.showerror("Erro", "RA inválido (7 caracteres alfanuméricos).")
                return
            if not validar_email_unip(vals.get("email", "")):
                messagebox.showerror("Erro", "E-mail deve ser institucional (@unip.edu.br).")
                return
            if not validar_senha(vals.get("senha", "")):
                messagebox.showerror("Erro", "Senha inválida (5 dígitos numéricos).")
                return

            conn = conectar()
            c = conn.cursor()
            try:
                c.execute(
                    """
                    INSERT INTO alunos (nome, data_nascimento, ra, senha, email)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (vals["nome"], vals["nasc"], vals["ra"], vals["senha"], vals["email"]),
                )
                # matricular em todas as matérias + criar registros base
                c.execute("SELECT id FROM materias")
                materias = [row[0] for row in c.fetchall()]
                for materia_id in materias:
                    c.execute(
                        "INSERT INTO matriculas (aluno_ra, materia_id) VALUES (?, ?)",
                        (vals["ra"], materia_id),
                    )
                    c.execute(
                        """
                        INSERT INTO notas (aluno_ra, materia_id, np1, np2, media)
                        VALUES (?, ?, NULL, NULL, NULL)
                        """,
                        (vals["ra"], materia_id),
                    )
                    c.execute(
                        """
                        INSERT INTO faltas (aluno_ra, materia_id, total_faltas, total_aulas)
                        VALUES (?, ?, 0, 120)
                        """,
                        (vals["ra"], materia_id),
                    )

                conn.commit()
                messagebox.showinfo("Sucesso", "Cadastro de aluno realizado!")
                cad.destroy()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao cadastrar aluno: {e}")
            finally:
                conn.close()

        else:
            # Professor
            if not vals.get("nome"):
                messagebox.showerror("Erro", "Informe o nome.")
                return
            if not validar_email_unip(vals.get("email", "")):
                messagebox.showerror("Erro", "E-mail deve ser institucional (@unip.edu.br).")
                return
            if not vals.get("disciplina"):
                messagebox.showerror("Erro", "Selecione uma disciplina.")
                return
            if not validar_senha(vals.get("senha", "")):
                messagebox.showerror("Erro", "Senha inválida (5 dígitos numéricos).")
                return

            conn = conectar()
            c = conn.cursor()
            try:
                c.execute(
                    """
                    INSERT INTO professores (nome, email, senha, disciplina)
                    VALUES (?, ?, ?, ?)
                    """,
                    (vals["nome"], vals["email"], vals["senha"], vals["disciplina"]),
                )
                conn.commit()
                messagebox.showinfo("Sucesso", "Cadastro de professor realizado!")
                cad.destroy()
            except Exception as e:
                messagebox.showerror("Erro", f"Erro ao cadastrar professor: {e}")
            finally:
                conn.close()

    tk.Button(
        cad,
        text="Salvar",
        bg=COR_AMARELO_UNIP,
        fg="black",
        font=("Arial", 10, "bold"),
        command=salvar,
    ).pack(pady=10)


# ---------------------- LOGIN ---------------------- #

def tela_login(tipo: str):
    """Janela de login para Aluno ou Professor."""
    win = tk.Toplevel()
    win.title(f"Login - {tipo.capitalize()}")
    win.configure(bg=COR_AZUL_MARINHO)
    win.geometry("380x260")

    tk.Label(
        win,
        text=f"Login de {tipo.capitalize()}",
        font=("Arial", 13, "bold"),
        bg=COR_AZUL_MARINHO,
        fg=COR_AMARELO_UNIP,
    ).pack(pady=10)

    frame = tk.Frame(win, bg=COR_AZUL_CLARO)
    frame.pack(padx=20, pady=10, fill="both", expand=True)

    if tipo == "aluno":
        tk.Label(frame, text="RA:", bg=COR_AZUL_CLARO).pack(pady=(10, 0))
        entry_id = tk.Entry(frame)
        entry_id.pack(pady=4)
    else:
        tk.Label(frame, text="E-mail institucional:", bg=COR_AZUL_CLARO).pack(pady=(10, 0))
        entry_id = tk.Entry(frame)
        entry_id.pack(pady=4)

    tk.Label(frame, text="Senha:", bg=COR_AZUL_CLARO).pack(pady=(10, 0))
    entry_senha = tk.Entry(frame, show="*")
    entry_senha.pack(pady=4)

    def entrar():
        identificador = entry_id.get().strip()
        senha = entry_senha.get().strip()
        dados = autenticar(tipo, identificador, senha)
        if dados:
            messagebox.showinfo("Sucesso", f"Bem-vindo(a), {dados[1]}!")
            win.destroy()
            if tipo == "aluno":
                tela_aluno(dados)
            else:
                tela_professor(dados)
        else:
            messagebox.showerror("Erro", "Credenciais incorretas.")

    tk.Button(
        frame,
        text="Entrar",
        bg=COR_VERDE_NOTA,
        fg="white",
        font=("Arial", 10, "bold"),
        command=entrar,
    ).pack(pady=10)

    tk.Button(
        frame,
        text="Não tem cadastro? Clique aqui",
        bg=COR_AMARELO_UNIP_ESCURO,
        command=lambda: tela_cadastro(tipo),
    ).pack(pady=(0, 10))


# ---------------------- COORDENADOR ---------------------- #

def tela_login_coordenador():
    win = tk.Toplevel()
    win.title("Login - Coordenador")
    win.configure(bg=COR_AZUL_MARINHO)
    win.geometry("360x220")

    tk.Label(
        win,
        text="Login de Coordenador",
        font=("Arial", 13, "bold"),
        bg=COR_AZUL_MARINHO,
        fg=COR_AMARELO_UNIP,
    ).pack(pady=10)

    frame = tk.Frame(win, bg=COR_AZUL_CLARO)
    frame.pack(padx=20, pady=10, fill="both", expand=True)

    tk.Label(frame, text="E-mail:", bg=COR_AZUL_CLARO).pack(pady=(10, 0))
    entry_email = tk.Entry(frame)
    entry_email.pack(pady=4, fill="x", padx=5)

    tk.Label(frame, text="Senha:", bg=COR_AZUL_CLARO).pack(pady=(10, 0))
    entry_senha = tk.Entry(frame, show="*")
    entry_senha.pack(pady=4, fill="x", padx=5)

    def entrar_coord():
        email = entry_email.get().strip()
        senha = entry_senha.get().strip()
        if email == COORDENADOR_EMAIL and senha == COORDENADOR_SENHA:
            messagebox.showinfo("Sucesso", "Bem-vindo(a), Coordenador!")
            win.destroy()
            tela_coordenador()
        else:
            messagebox.showerror("Erro", "Credenciais de coordenador inválidas.")

    tk.Button(
        frame,
        text="Entrar",
        bg=COR_VERDE_NOTA,
        fg="white",
        font=("Arial", 10, "bold"),
        command=entrar_coord,
    ).pack(pady=10)


def tela_coordenador():
    """Tela principal do Coordenador.
    Implementa:
    - Visualização de alunos e professores
    - Exclusão de aluno com motivo e confirmação de senha
    - Criação de novas matérias
    """
    win = tk.Toplevel()
    win.title("Coordenador - Painel Geral")
    win.configure(bg=COR_AZUL_MARINHO)
    win.geometry("760x500")

    tk.Label(
        win,
        text="Painel do Coordenador - ADS / UNIP",
        font=("Arial", 14, "bold"),
        bg=COR_AZUL_MARINHO,
        fg=COR_AMARELO_UNIP,
    ).pack(pady=8)

    notebook = ttk.Notebook(win)
    notebook.pack(fill="both", expand=True, padx=10, pady=10)

    # --- Aba Alunos ---
    frame_alunos = tk.Frame(notebook, bg=COR_AZUL_CLARO)
    notebook.add(frame_alunos, text="Alunos")

    lista_alunos = tk.Listbox(frame_alunos)
    lista_alunos.pack(side="left", fill="both", expand=True, padx=8, pady=8)

    scrollbar = tk.Scrollbar(frame_alunos, command=lista_alunos.yview)
    scrollbar.pack(side="right", fill="y")
    lista_alunos.config(yscrollcommand=scrollbar.set)

    conn = conectar()
    c = conn.cursor()
    c.execute("SELECT nome, ra FROM alunos ORDER BY nome")
    alunos_db = c.fetchall()
    conn.close()

    for nome, ra in alunos_db:
        lista_alunos.insert(tk.END, f"{nome} - RA: {ra}")

    def excluir_aluno():
        sel = lista_alunos.curselection()
        if not sel:
            messagebox.showwarning("Atenção", "Selecione um aluno na lista.")
            return
        texto = lista_alunos.get(sel[0])
        ra = texto.split("RA:")[-1].strip()

        # Modal para motivo + confirmação de senha
        modal = tk.Toplevel(win)
        modal.title("Excluir aluno")
        modal.geometry("400x320")
        modal.configure(bg=COR_AZUL_MARINHO)

        tk.Label(
            modal,
            text=f"Excluir aluno RA {ra}",
            bg=COR_AZUL_MARINHO,
            fg="white",
            font=("Arial", 11, "bold"),
        ).pack(pady=10)

        frame_motivo = tk.Frame(modal, bg=COR_AZUL_CLARO)
        frame_motivo.pack(fill="both", expand=True, padx=10, pady=10)

        tk.Label(
            frame_motivo,
            text="Informe o motivo:",
            bg=COR_AZUL_CLARO,
        ).pack(pady=(8, 4))

        motivo_var = tk.StringVar(value="transferido")

        opcoes = [
            ("Aluno transferido de campus.", "transferido"),
            ("Aluno trancou o curso.", "trancou"),
            ("Aluno em débito financeiro há mais de 6 meses.", "debito"),
        ]
        for texto_op, valor in opcoes:
            tk.Radiobutton(
                frame_motivo,
                text=texto_op,
                variable=motivo_var,
                value=valor,
                bg=COR_AZUL_CLARO,
                anchor="w",
            ).pack(fill="x", padx=10, pady=2)

        tk.Label(
            frame_motivo,
            text="Confirme a senha do coordenador:",
            bg=COR_AZUL_CLARO,
        ).pack(pady=(12, 4))
        entry_senha = tk.Entry(frame_motivo, show="*")
        entry_senha.pack(pady=4, padx=10, fill="x")

        def confirmar_exclusao():
            senha = entry_senha.get().strip()
            if senha != COORDENADOR_SENHA:
                messagebox.showerror("Erro", "Senha do coordenador incorreta.")
                return

            conn2 = conectar()
            c2 = conn2.cursor()
            # remove aluno e registros relacionados
            c2.execute("DELETE FROM alunos WHERE ra = ?", (ra,))
            c2.execute("DELETE FROM matriculas WHERE aluno_ra = ?", (ra,))
            c2.execute("DELETE FROM notas WHERE aluno_ra = ?", (ra,))
            c2.execute("DELETE FROM faltas WHERE aluno_ra = ?", (ra,))
            c2.execute("DELETE FROM ocorrencias WHERE aluno_ra = ?", (ra,))
            conn2.commit()
            conn2.close()

            lista_alunos.delete(sel[0])
            messagebox.showinfo("Sucesso", "Aluno excluído de todos os registros.")
            modal.destroy()

        tk.Button(
            frame_motivo,
            text="Confirmar exclusão",
            bg=COR_VERMELHO_NOTA,
            fg="white",
            command=confirmar_exclusao,
        ).pack(pady=10)

    tk.Button(
        frame_alunos,
        text="Excluir aluno selecionado",
        bg=COR_VERMELHO_NOTA,
        fg="white",
        command=excluir_aluno,
    ).pack(pady=4)

    # --- Aba Professores ---
    frame_prof = tk.Frame(notebook, bg=COR_AZUL_CLARO)
    notebook.add(frame_prof, text="Professores")

    lista_prof = tk.Listbox(frame_prof)
    lista_prof.pack(side="left", fill="both", expand=True, padx=8, pady=8)
    sb_prof = tk.Scrollbar(frame_prof, command=lista_prof.yview)
    sb_prof.pack(side="right", fill="y")
    lista_prof.config(yscrollcommand=sb_prof.set)

    conn = conectar()
    c = conn.cursor()
    c.execute("SELECT nome, email, disciplina FROM professores ORDER BY nome")
    profs_db = c.fetchall()
    conn.close()

    for nome, email, disc in profs_db:
        lista_prof.insert(tk.END, f"{nome} - {email} - {disc}")

    # --- Aba Matérias ---
    frame_mat = tk.Frame(notebook, bg=COR_AZUL_CLARO)
    notebook.add(frame_mat, text="Matérias")

    lista_mat = tk.Listbox(frame_mat)
    lista_mat.pack(side="left", fill="both", expand=True, padx=8, pady=8)
    sb_mat = tk.Scrollbar(frame_mat, command=lista_mat.yview)
    sb_mat.pack(side="right", fill="y")
    lista_mat.config(yscrollcommand=sb_mat.set)

    conn = conectar()
    c = conn.cursor()
    c.execute("SELECT nome FROM materias ORDER BY nome")
    materias_db = [row[0] for row in c.fetchall()]
    conn.close()

    for nome in materias_db:
        lista_mat.insert(tk.END, nome)

    frame_nova = tk.Frame(frame_mat, bg=COR_AZUL_CLARO)
    frame_nova.pack(fill="x", padx=8, pady=8)

    tk.Label(frame_nova, text="Nova matéria:", bg=COR_AZUL_CLARO).pack(anchor="w")
    entry_nova_mat = tk.Entry(frame_nova)
    entry_nova_mat.pack(fill="x", pady=4)

    def criar_materia():
        nome = entry_nova_mat.get().strip()
        if not nome:
            messagebox.showwarning("Atenção", "Informe o nome da matéria.")
            return
        conn2 = conectar()
        c2 = conn2.cursor()
        try:
            c2.execute("INSERT INTO materias (nome) VALUES (?)", (nome,))
            conn2.commit()
            lista_mat.insert(tk.END, nome)
            messagebox.showinfo("Sucesso", "Matéria criada.")
            entry_nova_mat.delete(0, tk.END)
        except Exception as e:
            messagebox.showerror("Erro", f"Não foi possível criar matéria: {e}")
        finally:
            conn2.close()

    tk.Button(
        frame_nova,
        text="Criar matéria",
        bg=COR_AMARELO_UNIP,
        fg="black",
        command=criar_materia,
    ).pack(pady=4)


# ---------------------- JANELA INICIAL ---------------------- #

def main():
    # Inicializa banco base e tabelas/com dados adicionais
    inicializar_banco()
    criar_tabelas_complementares()
    popular_dados_iniciais()

    root = tk.Tk()
    root.title("Sistema Acadêmico Colaborativo - UNIP")
    root.configure(bg=COR_AZUL_MARINHO)
    root.geometry("500x420")

    # Caso você tenha um ícone .ico da UNIP, pode setar aqui:
    # try:
    #     root.iconbitmap("unip.ico")
    # except Exception:
    #     pass

    container = tk.Frame(root, bg=COR_AZUL_MARINHO)
    container.pack(fill="both", expand=True)

    tk.Label(
        container,
        text="Sistema Acadêmico Colaborativo com IA",
        font=("Arial", 16, "bold"),
        bg=COR_AZUL_MARINHO,
        fg=COR_AMARELO_UNIP,
    ).pack(pady=(20, 5))

    tk.Label(
        container,
        text="Curso ADS - Noturno - Campus Anchieta (2º semestre)",
        font=("Arial", 10),
        bg=COR_AZUL_MARINHO,
        fg="white",
    ).pack(pady=(0, 15))

    frame_botoes = tk.Frame(container, bg=COR_AZUL_MARINHO)
    frame_botoes.pack(pady=10, fill="x")

    # Botões grandes, um abaixo do outro (layout vertical)
    tk.Button(
        frame_botoes,
        text="Sou Aluno",
        width=28,
        height=2,
        bg=COR_AMARELO_UNIP_ESCURO,
        fg="black",
        font=("Arial", 11, "bold"),
        command=lambda: tela_login("aluno"),
    ).pack(pady=8)

    tk.Button(
        frame_botoes,
        text="Sou Professor",
        width=28,
        height=2,
        bg="#673ab7",
        fg="white",
        font=("Arial", 11, "bold"),
        command=lambda: tela_login("professor"),
    ).pack(pady=8)

    tk.Button(
        frame_botoes,
        text="Sou Coordenador",
        width=28,
        height=2,
        bg="#f44336",
        fg="white",
        font=("Arial", 11, "bold"),
        command=tela_login_coordenador,
    ).pack(pady=8)

    tk.Label(
        container,
        text=(
            "Alunos padrão: RA A123456..E123456, senha 12345\n"
            "Professores padrão: email @unip.edu.br, senha 12345\n"
            "Coordenador: coordenadorads@unip.edu.br / 1234567"
        ),
        font=("Arial", 8),
        bg=COR_AZUL_MARINHO,
        fg="white",
    ).pack(side="bottom", pady=10)

    root.mainloop()


if __name__ == "__main__":
    main()
